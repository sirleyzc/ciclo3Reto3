package com.ciclo3.reto3.repository.crud;

import org.springframework.data.repository.CrudRepository;

import com.ciclo3.reto3.model.Admin;

public interface AdminCrudRepository extends CrudRepository<Admin, Integer> {
    
}
